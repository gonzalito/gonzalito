var group__commands =
[
    [ "SimulateCommand", "classlirc_1_1client_1_1SimulateCommand.html", [
      [ "__init__", "classlirc_1_1client_1_1SimulateCommand.html#a040cf594f24115c97b709500c7f1218f", null ]
    ] ],
    [ "ListRemotesCommand", "classlirc_1_1client_1_1ListRemotesCommand.html", [
      [ "__init__", "classlirc_1_1client_1_1ListRemotesCommand.html#a095bd30bdc38fd3868972fc2e7dbe29a", null ]
    ] ],
    [ "ListKeysCommand", "classlirc_1_1client_1_1ListKeysCommand.html", [
      [ "__init__", "classlirc_1_1client_1_1ListKeysCommand.html#af5f0729e76ac480e7e93a9b4f09a6569", null ]
    ] ],
    [ "StartRepeatCommand", "classlirc_1_1client_1_1StartRepeatCommand.html", [
      [ "__init__", "classlirc_1_1client_1_1StartRepeatCommand.html#a9b8a6ace7d50fcb3af74e4e72470efac", null ]
    ] ],
    [ "StopRepeatCommand", "classlirc_1_1client_1_1StopRepeatCommand.html", [
      [ "__init__", "classlirc_1_1client_1_1StopRepeatCommand.html#a212bd811ffe3390a7fe5b3423b550d30", null ]
    ] ],
    [ "SendCommand", "classlirc_1_1client_1_1SendCommand.html", [
      [ "__init__", "classlirc_1_1client_1_1SendCommand.html#a642359fc24d5c521ea68463fd01ebae0", null ]
    ] ],
    [ "SetTransmittersCommand", "classlirc_1_1client_1_1SetTransmittersCommand.html", [
      [ "__init__", "classlirc_1_1client_1_1SetTransmittersCommand.html#a694f6829b09fd575d3a50bcd8982a94c", null ]
    ] ],
    [ "VersionCommand", "classlirc_1_1client_1_1VersionCommand.html", [
      [ "__init__", "classlirc_1_1client_1_1VersionCommand.html#acd775579935cf6364bba6932a08eb430", null ]
    ] ],
    [ "DrvOptionCommand", "classlirc_1_1client_1_1DrvOptionCommand.html", [
      [ "__init__", "classlirc_1_1client_1_1DrvOptionCommand.html#a3e4b9f7f514237c67ed8e0017510cb94", null ]
    ] ],
    [ "SetLogCommand", "classlirc_1_1client_1_1SetLogCommand.html", [
      [ "__init__", "classlirc_1_1client_1_1SetLogCommand.html#ac9d91ca85d80dc6ed09e14655e853781", null ]
    ] ]
];