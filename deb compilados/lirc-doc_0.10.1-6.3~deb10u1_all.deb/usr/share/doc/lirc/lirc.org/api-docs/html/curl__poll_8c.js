var curl__poll_8c =
[
    [ "_XOPEN_SOURCE", "curl__poll_8c.html#a78c99ffd76a7bb3c8c74db76207e9ab4", null ],
    [ "FALSE", "curl__poll_8c.html#aa93f0eb578d23995850d61f7d61c55c1", null ],
    [ "TRUE", "curl__poll_8c.html#aa8cecfc5c5c054d2875c03e77b7be15d", null ],
    [ "curl_poll", "curl__poll_8c.html#ad952c4f6807cbe40b08f64516ed5e710", null ],
    [ "curlx_tvdiff", "curl__poll_8c.html#a32589df2f6cc2c3c45681daf583a574a", null ]
];