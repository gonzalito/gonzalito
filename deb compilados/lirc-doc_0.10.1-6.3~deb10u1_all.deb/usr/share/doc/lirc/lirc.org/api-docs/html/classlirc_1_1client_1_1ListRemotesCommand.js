var classlirc_1_1client_1_1ListRemotesCommand =
[
    [ "__init__", "classlirc_1_1client_1_1ListRemotesCommand.html#a095bd30bdc38fd3868972fc2e7dbe29a", null ]
];