var modules =
[
    [ "Driver API manual excerpt", "group__driver__manual.html", null ],
    [ "Client API manual excerpt.", "group__client__manual.html", null ],
    [ "Client API", "group__lirc__client.html", "group__lirc__client" ],
    [ "User-space driver API", "group__driver__api.html", "group__driver__api" ],
    [ "Internal API", "group__private__api.html", "group__private__api" ],
    [ "Python client bindings", "group__python__bindings.html", "group__python__bindings" ],
    [ "python configuration database", "group__database.html", "group__database" ],
    [ "Ciniparser", "group__ciniparser.html", "group__ciniparser" ]
];