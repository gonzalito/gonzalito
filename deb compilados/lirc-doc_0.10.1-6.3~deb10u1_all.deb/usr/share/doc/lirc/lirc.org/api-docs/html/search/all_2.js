var searchData=
[
  ['badpacketexception',['BadPacketException',['../classlirc_1_1client_1_1BadPacketException.html',1,'lirc::client']]],
  ['baud',['baud',['../structir__remote.html#a9e93a637e00eb62f9118b5059b361f08',1,'ir_remote']]],
  ['bits',['bits',['../structir__remote.html#a66c874209817af89bc88503f61a76539',1,'ir_remote']]],
  ['bits_5fin_5fbyte',['bits_in_byte',['../structir__remote.html#a1fd7f2e6b078e14bc48407ef2db2c406',1,'ir_remote']]],
  ['bo',['BO',['../ir__remote__types_8h.html#a449e8aac922c7f3659cbbf80cf88df10',1,'ir_remote_types.h']]],
  ['btn_5fstate_5fset_5fmessage',['btn_state_set_message',['../irrecord_8c.html#ae8ed0747eb2c2813250f6f6bd002e511',1,'btn_state_set_message(struct button_state *state, const char *fmt,...):&#160;irrecord.c'],['../irrecord_8h.html#ae8ed0747eb2c2813250f6f6bd002e511',1,'btn_state_set_message(struct button_state *state, const char *fmt,...):&#160;irrecord.c']]],
  ['buffer',['buffer',['../structlirc__cmd__ctx.html#a88d6468e428af670b4842b5cb91fec77',1,'lirc_cmd_ctx']]],
  ['button_5fstate',['button_state',['../structbutton__state.html',1,'']]],
  ['button_5fstate_5finit',['button_state_init',['../irrecord_8c.html#a6dc19e536c08e4e174591485d5c62697',1,'button_state_init(struct button_state *state, int started_as_root):&#160;irrecord.c'],['../irrecord_8h.html#a6dc19e536c08e4e174591485d5c62697',1,'button_state_init(struct button_state *state, int started_as_root):&#160;irrecord.c']]],
  ['button_5fstatus',['button_status',['../irrecord_8h.html#a3ba15f6896e40b9ba6c5bf1d398dab4a',1,'irrecord.h']]]
];
