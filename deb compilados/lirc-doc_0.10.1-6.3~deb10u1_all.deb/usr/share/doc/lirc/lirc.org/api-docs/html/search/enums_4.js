var searchData=
[
  ['packet_5fstate',['packet_state',['../lirc__client_8c.html#aacdc622aa02a946d7a3d67c361199733',1,'lirc_client.c']]]
];
