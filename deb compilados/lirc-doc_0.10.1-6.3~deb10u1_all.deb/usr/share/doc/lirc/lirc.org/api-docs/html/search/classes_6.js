var searchData=
[
  ['gap_5fstate',['gap_state',['../structgap__state.html',1,'']]],
  ['getmodecommand',['GetModeCommand',['../classlirc_1_1client_1_1GetModeCommand.html',1,'lirc::client']]]
];
