var classLineBuffer =
[
    [ "LineBuffer", "classLineBuffer.html#ac665cdce15c8a9b24c8303aebe15163c", null ],
    [ "append", "classLineBuffer.html#a637893678418fa0ae4517891b3f1d1c1", null ],
    [ "c_str", "classLineBuffer.html#a361228fec97d5160370b9ab185e03ea6", null ],
    [ "get_next_line", "classLineBuffer.html#ae5eb2bcd8c98c58df8fa525c4d498613", null ],
    [ "has_lines", "classLineBuffer.html#aeeb6e44909d8847341b43c99555bbf46", null ]
];