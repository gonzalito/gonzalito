var classlirc_1_1client_1_1VersionCommand =
[
    [ "__init__", "classlirc_1_1client_1_1VersionCommand.html#acd775579935cf6364bba6932a08eb430", null ]
];