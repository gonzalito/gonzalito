var searchData=
[
  ['serial',['SERIAL',['../ir__remote__types_8h.html#aae3f0b4211ba45d265973d40ccbb5fd1',1,'ir_remote_types.h']]],
  ['shift_5fenc',['SHIFT_ENC',['../ir__remote__types_8h.html#a1a3e70543f0b4b37b11cf675e16edc78',1,'ir_remote_types.h']]],
  ['socket_5ftimeout',['SOCKET_TIMEOUT',['../lirc__config_8h.html#aca6153015dc94fe7679954a1ff9d9b15',1,'lirc_config.h']]],
  ['space_5fenc',['SPACE_ENC',['../ir__remote__types_8h.html#a6db726257ddd9e6843e40ea379b6319f',1,'ir_remote_types.h']]],
  ['space_5ffirst',['SPACE_FIRST',['../ir__remote__types_8h.html#a595e544f9dbe598b635b48383f57425a',1,'ir_remote_types.h']]],
  ['str',['STR',['../lirc__log_8h.html#a18d295a837ac71add5578860b55e5502',1,'lirc_log.h']]],
  ['stringify',['STRINGIFY',['../lirc__log_8h.html#a6df1d22fb5f09eccc23b9f399670cfd7',1,'lirc_log.h']]]
];
