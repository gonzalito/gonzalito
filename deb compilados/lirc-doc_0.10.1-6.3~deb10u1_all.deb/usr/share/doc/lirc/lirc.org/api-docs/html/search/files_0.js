var searchData=
[
  ['_5fclient_2ec',['_client.c',['../__client_8c.html',1,'']]]
];
